The aim of  this module is to collect some important functions and applications in python and make them simple. From now on no more struggling to write hundreds of lines of code. Simple tell us what you want in one line. We've done it for you.

Test Pypi source - https://test.pypi.org/project/Littledog-LittleDog5727/0.0.3/ (Source code & Build)
Official website - https://www.sites.google.com/view/littledog-python