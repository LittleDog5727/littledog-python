The aim of  this module is to collect some important functions and applications in python and make them simple. From now on no more struggling to write hundreds of lines of code. Simply tell us what you want in one line. We've done it for you.

Test Pypi source - https://test.pypi.org/project/Littledog-LittleDog5727/0.1.0/ (Source code & Build)<br>
Pypi source - https://pypi.org/project/Littledog/0.1.0/<br>
Official website - https://www.sites.google.com/view/littledog-python<br>
Github repository - https://github.com/LittleDog5727/littledog-python